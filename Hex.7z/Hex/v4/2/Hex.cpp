#include <stdio.h>
#include <string.h>
#include <iostream>
#include <fstream>

int hex_to_int(char c)
{
    if (c >= 97)
        c = c - 32;
    int first = c / 16 - 3;
    int second = c % 16;
    int result = first * 10 + second;
    if (result > 9) result--;
    return result;
}

int hex_to_ascii(char c, char d){
        int high = hex_to_int(c) * 16;
        int low = hex_to_int(d);
        return high+low;
}

int main(){
	
   std::string line,text;
   std::ifstream in("Input.txt");
   while(std::getline(in, line))
   {
       text += line ;
   }
        const char* st = text.c_str();
        int length = strlen(st);
        int i;
        char buf = 0;
        for(i = 0; i < length; i++){
                if(i % 2 != 0){
                printf("%c", hex_to_ascii(buf, st[i]));
                std::cout << std::flush;
                }else{
                        buf = st[i];	                      
                }
        }
}
 
 





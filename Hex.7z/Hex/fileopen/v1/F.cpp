#include <iostream>
#include <fstream> // the class declarations for file stream objects
#include <cstdlib>
using namespace std;


int main ()
{

ifstream my_input_file("input_data.txt"); // create and open
ofstream my_output_file("output_data.txt");




my_output_file << "The integer is " << int_var << endl;

my_input_file.close(); // close the file associated with this stream
my_output_file.close(); // close the file associated with this stream

}

if (my_input_file.is_open()) {
! ! // can continue, file opened correctly
! ! }

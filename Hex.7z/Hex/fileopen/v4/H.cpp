#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace std;


int hex_to_int(char c)
{
    if (c >= 97)
        c = c - 32;
    int first = c / 16 - 3;
    int second = c % 16;
    int result = first * 10 + second;
    if (result > 9) result--;
    return result;
}

int hex_to_ascii(char c, char d){
        int high = hex_to_int(c) * 16;
        int low = hex_to_int(d);
        return high+low;
}

int main(){
ifstream input_file("data.input"); // open the input file
if (!input_file.is_open()) { // check for successful opening
 cout << "Input file could not be opened! Terminating!" << endl;
 return 1;
 }
ofstream output_file("data.output"); // open the output file
if (!output_file.is_open()) { // check for successful opening
 cout << "Output file could not be opened! Terminating!" << endl;
 return 1;
 }	
	
	const char* datum;
while (input_file >> datum) {
 
        const char* st = datum;
        int length = strlen(st);
        int i;
        char buf = 0;
        for(i = 0; i < length; i++){
                if(i % 2 != 0){
                        printf("%c", hex_to_ascii(buf, st[i]));
                }else{
                        buf = st[i];
                }
        }
}


input_file.close();
output_file.close();
cout << "Done!" << endl;
    system("pause");
return 0;
}
